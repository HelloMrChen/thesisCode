CREATE VIEW dataresultone AS
  SELECT
    `matchsummaryone`.`match_ID`                                                                       AS `matchID`,
    `matchsummaryone`.`isRadiantWin`                                                                   AS `isRadiantWin`,
    `matchsummaryone`.`Duration`                                                                       AS `Duration`,
    `matchsummaryone`.`region`                                                                         AS `region`,
    `matchsummaryone`.`isChina`                                                                        AS `isChina`,
    `matchsummaryone`.`isAsia`                                                                         AS `isAsia`,
    `matchsummaryone`.`gameModeName`                                                                   AS `gameModeName`,
    `matchsummaryone`.`isProfessional`                                                                 AS `isProfessional`,
    `matchsummaryone`.`positiveVotes`                                                                  AS `positiveVotes`,
    `matchsummaryone`.`negativeVote`                                                                   AS `negativeVotes`,
    `matchsummaryone`.`robotRate`                                                                      AS `robotRate`,
    `matchsummaryone`.`playerID`                                                                       AS `playerAccountID`,
    `matchsummaryone`.`position`                                                                       AS `position`,
    `matchsummaryone`.`Team`                                                                           AS `Team`,
    `matchsummaryone`.`TeamName`                                                                       AS `TeamName`,
    `matchsummaryone`.`PlayerTeamWin`                                                                  AS `PlayerTeamWin`,
    `matchsummaryone`.`Kills`                                                                          AS `Kills`,
    `matchsummaryone`.`Assists`                                                                        AS `Assists`,
    `matchsummaryone`.`Deaths`                                                                         AS `Deaths`,
    ((`matchsummaryone`.`Kills` + `matchsummaryone`.`Assists`) / `matchsummaryone`.`Deaths`)           AS `KDA`,
    `matchsummaryone`.`LastHits`                                                                       AS `LastHits`,
    `matchsummaryone`.`Denies`                                                                         AS `Denies`,
    `matchsummaryone`.`XPM`                                                                            AS `XPM`,
    `matchsummaryone`.`GPM`                                                                            AS `GPM`,
    `matchsummaryone`.`Glod`                                                                           AS `Gold`,
    `matchsummaryone`.`GoldSpent`                                                                      AS `GoldSpent`,
    `matchsummaryone`.`HeroDamage`                                                                     AS `HeroDamage`,
    `matchsummaryone`.`TowerDamage`                                                                    AS `TowerDamage`,
    `matchsummaryone`.`HeroHealing`                                                                    AS `HeroHealing`,
    `matchsummaryone`.`TeamWin`                                                                        AS `TeamWin`,
    `matchsummaryone`.`Teamkills`                                                                      AS `Teamkills`,
    `matchsummaryone`.`TeamAssist`                                                                     AS `TeamAssist`,
    `matchsummaryone`.`TeamDeath`                                                                      AS `TeamDeath`,
    ((`matchsummaryone`.`TeamAssist` + `matchsummaryone`.`Teamkills`) / `matchsummaryone`.`TeamDeath`) AS `TeamKDA`,
    `matchsummaryone`.`TeamLastHits`                                                                   AS `TeamLastHits`,
    `matchsummaryone`.`TeamDenies`                                                                     AS `TeamDenies`,
    `matchsummaryone`.`TeamXPM`                                                                        AS `TeamXPM`,
    `matchsummaryone`.`TeamGPM`                                                                        AS `TeamGPM`,
    `matchsummaryone`.`TeamHeroHealing`                                                                AS `TeamHeroHealing`,
    `matchsummaryone`.`TeamHeroDamage`                                                                 AS `TeamHeroDamage`,
    `matchsummaryone`.`TeamTowerDamage`                                                                AS `TeamTowerDamage`,
    `matchsummaryone`.`TeamGold`                                                                       AS `TeamGold`,
    `matchsummaryone`.`TeamGlodSpent`                                                                  AS `TeamGlodSpent`,
    `matchsummarytwo`.`playerID`                                                                       AS `playerID`,
    `matchsummarytwo`.`playerWinRate`                                                                  AS `playerWinRate`,
    `matchsummarytwo`.`playerAvgKills`                                                                 AS `playerAvgKills`,
    `matchsummarytwo`.`playerAvgAssists`                                                               AS `playerAvgAssists`,
    `matchsummarytwo`.`playerAvgDeaths`                                                                AS `playerAvgDeaths`,
    ((`matchsummarytwo`.`playerAvgKills` + `matchsummarytwo`.`playerAvgAssists`) /
     `matchsummarytwo`.`playerAvgDeaths`)                                                              AS `playerAvgKDA`,
    `matchsummarytwo`.`playerAvgLastHits`                                                              AS `playerAvgLastHits`,
    `matchsummarytwo`.`playerAvgDenies`                                                                AS `playerAvgDenies`,
    `matchsummarytwo`.`playerAvgXPM`                                                                   AS `playerAvgXPM`,
    `matchsummarytwo`.`playerAvgGPM`                                                                   AS `playerAvgGPM`,
    `matchsummarytwo`.`playerAvgGlod`                                                                  AS `playerAvgGlod`,
    `matchsummarytwo`.`playerAvgGlodSpent`                                                             AS `playerAvgGlodSpent`,
    `matchsummarytwo`.`playerAvgHeroDamage`                                                            AS `playerAvgHeroDamage`,
    `matchsummarytwo`.`playerAvgTowerDamage`                                                           AS `playerAvgTowerDamage`,
    `matchsummarytwo`.`playerAvgHeroHealing`                                                           AS `playerAvgHeroHealing`,
    `matchsummarytwo`.`totalLeaveNum`                                                                  AS `totalLeaveNum`
  FROM ((SELECT
           `matchdetailsummary`.`matchID`        AS `matchID`,
           `matchdetailsummary`.`isRadiantWin`   AS `isRadiantWin`,
           `matchdetailsummary`.`region`         AS `region`,
           `matchdetailsummary`.`isChina`        AS `isChina`,
           `matchdetailsummary`.`isAsia`         AS `isAsia`,
           `matchdetailsummary`.`Duration`       AS `Duration`,
           `matchdetailsummary`.`positiveVotes`  AS `positiveVotes`,
           `matchdetailsummary`.`negativeVote`   AS `negativeVote`,
           `matchdetailsummary`.`gameModeName`   AS `gameModeName`,
           `matchdetailsummary`.`isProfessional` AS `isProfessional`,
           `matchdetailsummary`.`robotRate`      AS `robotRate`,
           `matchdetailsummary`.`playerID`       AS `playerID`,
           `matchdetailsummary`.`playerHeroName` AS `playerHeroName`,
           `matchdetailsummary`.`position`       AS `position`,
           `matchdetailsummary`.`Team`           AS `Team`,
           `matchdetailsummary`.`TeamName`       AS `TeamName`,
           `matchdetailsummary`.`PlayerTeamWin`  AS `PlayerTeamWin`,
           `matchdetailsummary`.`Kills`          AS `Kills`,
           `matchdetailsummary`.`Assists`        AS `Assists`,
           `matchdetailsummary`.`Deaths`         AS `Deaths`,
           `matchdetailsummary`.`LastHits`       AS `LastHits`,
           `matchdetailsummary`.`Denies`         AS `Denies`,
           `matchdetailsummary`.`XPM`            AS `XPM`,
           `matchdetailsummary`.`GPM`            AS `GPM`,
           `matchdetailsummary`.`Glod`           AS `Glod`,
           `matchdetailsummary`.`GoldSpent`      AS `GoldSpent`,
           `matchdetailsummary`.`HeroDamage`     AS `HeroDamage`,
           `matchdetailsummary`.`TowerDamage`    AS `TowerDamage`,
           `matchdetailsummary`.`HeroHealing`    AS `HeroHealing`,
           `matchdetailsummary`.`TeamWin`        AS `TeamWin`,
           `teamsummary`.`match_ID`              AS `match_ID`,
           `teamsummary`.`playerTeam`            AS `playerTeam`,
           `teamsummary`.`Teamkills`             AS `Teamkills`,
           `teamsummary`.`TeamAssist`            AS `TeamAssist`,
           `teamsummary`.`TeamDeath`             AS `TeamDeath`,
           `teamsummary`.`TeamLastHits`          AS `TeamLastHits`,
           `teamsummary`.`TeamDenies`            AS `TeamDenies`,
           `teamsummary`.`TeamXPM`               AS `TeamXPM`,
           `teamsummary`.`TeamGPM`               AS `TeamGPM`,
           `teamsummary`.`TeamHeroHealing`       AS `TeamHeroHealing`,
           `teamsummary`.`TeamHeroDamage`        AS `TeamHeroDamage`,
           `teamsummary`.`TeamTowerDamage`       AS `TeamTowerDamage`,
           `teamsummary`.`TeamGold`              AS `TeamGold`,
           `teamsummary`.`TeamGlodSpent`         AS `TeamGlodSpent`
         FROM ((SELECT
                  `Summary`.`match_ID`                   AS `matchID`,
                  `Summary`.`radiant_win`                AS `isRadiantWin`,
                  `Summary`.`cluster_name`               AS `region`,
                  (CASE WHEN (`Summary`.`cluster_name` = 'China')
                    THEN 1
                   ELSE 0 END)                           AS `isChina`,
                  (CASE WHEN ((`Summary`.`cluster_name` LIKE '%Asia') OR (`Summary`.`cluster_name` = 'China') OR
                              (`Summary`.`cluster_name` = 'Japan'))
                    THEN 1
                   ELSE 0 END)                           AS `isAsia`,
                  sec_to_time(`Summary`.`duration`)      AS `Duration`,
                  `Summary`.`positive_votes`             AS `positiveVotes`,
                  `Summary`.`negative_votes`             AS `negativeVote`,
                  `Summary`.`game_mode_name`             AS `gameModeName`,
                  (CASE WHEN ((`Summary`.`game_mode` = '1') OR (`Summary`.`game_mode` = '2') OR
                              (`Summary`.`game_mode` = '22'))
                    THEN 1
                   ELSE 0 END)                           AS `isProfessional`,
                  (1 - (`Summary`.`human_players` / 10)) AS `robotRate`,
                  `Detail`.`account_id`                  AS `playerID`,
                  `Detail`.`hero_name`                   AS `playerHeroName`,
                  (CASE WHEN (`Detail`.`player_slot` > 100)
                    THEN (`Detail`.`player_slot` - 128)
                   ELSE `Detail`.`player_slot` END)      AS `position`,
                  (CASE WHEN (`Detail`.`player_slot` > 100)
                    THEN '1'
                   ELSE '0' END)                         AS `Team`,
                  (CASE WHEN (`Detail`.`player_slot` > 100)
                    THEN 'Dire'
                   ELSE 'Radiant' END)                   AS `TeamName`,
                  (CASE WHEN (if((`Detail`.`player_slot` > 100), 0, 1) = `Summary`.`radiant_win`)
                    THEN 1
                   ELSE 0 END)                           AS `PlayerTeamWin`,
                  `Detail`.`kills`                       AS `Kills`,
                  `Detail`.`assists`                     AS `Assists`,
                  `Detail`.`deaths`                      AS `Deaths`,
                  `Detail`.`last_hits`                   AS `LastHits`,
                  `Detail`.`denies`                      AS `Denies`,
                  `Detail`.`xp_per_min`                  AS `XPM`,
                  `Detail`.`gold_per_min`                AS `GPM`,
                  `Detail`.`gold`                        AS `Glod`,
                  `Detail`.`gold_spent`                  AS `GoldSpent`,
                  `Detail`.`hero_damage`                 AS `HeroDamage`,
                  `Detail`.`tower_damage`                AS `TowerDamage`,
                  `Detail`.`hero_healing`                AS `HeroHealing`,
                  (CASE WHEN (if((`Detail`.`player_slot` > 100), 0, 1) = `Summary`.`radiant_win`)
                    THEN 1
                   ELSE 0 END)                           AS `TeamWin`
                FROM (`datasource`.`matchsummary` `Summary` LEFT JOIN `datasource`.`matchplayers` `Detail`
                    ON ((`Summary`.`match_ID` = `Detail`.`match_ID`)))) `matchDetailSummary` LEFT JOIN (SELECT
                                                                                                          `datasource`.`matchplayers`.`match_ID`          AS `match_ID`,
                                                                                                          (CASE WHEN (
                                                                                                            `datasource`.`matchplayers`.`player_slot`
                                                                                                            > 100)
                                                                                                            THEN '1'
                                                                                                           ELSE '0' END)                                  AS `playerTeam`,
                                                                                                          sum(
                                                                                                              `datasource`.`matchplayers`.`kills`)        AS `Teamkills`,
                                                                                                          sum(
                                                                                                              `datasource`.`matchplayers`.`assists`)      AS `TeamAssist`,
                                                                                                          sum(
                                                                                                              `datasource`.`matchplayers`.`deaths`)       AS `TeamDeath`,
                                                                                                          sum(
                                                                                                              `datasource`.`matchplayers`.`last_hits`)    AS `TeamLastHits`,
                                                                                                          sum(
                                                                                                              `datasource`.`matchplayers`.`denies`)       AS `TeamDenies`,
                                                                                                          sum(
                                                                                                              `datasource`.`matchplayers`.`xp_per_min`)   AS `TeamXPM`,
                                                                                                          sum(
                                                                                                              `datasource`.`matchplayers`.`gold_per_min`) AS `TeamGPM`,
                                                                                                          sum(
                                                                                                              `datasource`.`matchplayers`.`hero_healing`) AS `TeamHeroHealing`,
                                                                                                          sum(
                                                                                                              `datasource`.`matchplayers`.`hero_damage`)  AS `TeamHeroDamage`,
                                                                                                          sum(
                                                                                                              `datasource`.`matchplayers`.`tower_damage`) AS `TeamTowerDamage`,
                                                                                                          sum(
                                                                                                              `datasource`.`matchplayers`.`gold`)         AS `TeamGold`,
                                                                                                          sum(
                                                                                                              `datasource`.`matchplayers`.`gold_spent`)   AS `TeamGlodSpent`
                                                                                                        FROM
                                                                                                          `datasource`.`matchplayers`
                                                                                                        GROUP BY
                                                                                                          `datasource`.`matchplayers`.`match_ID`,
                                                                                                          `playerTeam`) `TeamSummary`
             ON (((`matchdetailsummary`.`matchID` = `teamsummary`.`match_ID`) AND
                  (`teamsummary`.`playerTeam` = `matchdetailsummary`.`Team`))))) `matchSummaryOne` LEFT JOIN
    (SELECT DISTINCT
       `playerhistorytableone`.`playerID`                        AS `playerID`,
       format(`playerhistorytabletwo`.`playerWinRate`, 2)        AS `playerWinRate`,
       `playerhistorytabletwo`.`matchNum`                        AS `matchNum`,
       `playerhistorytabletwo`.`totalLeaveNum`                   AS `totalLeaveNum`,
       format(`playerhistorytabletwo`.`playerAvgAssists`, 2)     AS `playerAvgAssists`,
       format(`playerhistorytabletwo`.`playerAvgDeaths`, 2)      AS `playerAvgDeaths`,
       format(`playerhistorytabletwo`.`playerAvgDenies`, 2)      AS `playerAvgDenies`,
       format(`playerhistorytabletwo`.`playerAvgLastHits`, 2)    AS `playerAvgLastHits`,
       format(`playerhistorytabletwo`.`playerAvgGlod`, 2)        AS `playerAvgGlod`,
       format(`playerhistorytabletwo`.`playerAvgGlodSpent`, 2)   AS `playerAvgGlodSpent`,
       format(`playerhistorytabletwo`.`playerAvgGPM`, 2)         AS `playerAvgGPM`,
       format(`playerhistorytabletwo`.`playerAvgHeroDamage`, 2)  AS `playerAvgHeroDamage`,
       format(`playerhistorytabletwo`.`playerAvgHeroHealing`, 2) AS `playerAvgHeroHealing`,
       format(`playerhistorytabletwo`.`playerAvgTowerDamage`, 2) AS `playerAvgTowerDamage`,
       format(`playerhistorytabletwo`.`playerAvgXPM`, 2)         AS `playerAvgXPM`,
       format(`playerhistorytabletwo`.`playersAvgKills`, 2)      AS `playerAvgKills`
     FROM ((SELECT `playermaxheronametable`.`playerID` AS `playerID`
            FROM ((SELECT
                     `a`.`playerID`       AS `playerID`,
                     `a`.`maxNum`         AS `maxNum`,
                     `b`.`playerHeroName` AS `playerMaxHeroName`
                   FROM ((SELECT
                            max(`a`.`num`) AS `maxNum`,
                            `a`.`playerID` AS `playerID`
                          FROM (SELECT
                                  count(0)                                                  AS `num`,
                                  `datasource`.`playerhistorymatchsummary`.`playerID`       AS `playerID`,
                                  `datasource`.`playerhistorymatchsummary`.`playerHeroName` AS `playerHeroName`
                                FROM `datasource`.`playerhistorymatchsummary`
                                GROUP BY `datasource`.`playerhistorymatchsummary`.`playerID`,
                                  `datasource`.`playerhistorymatchsummary`.`playerHeroName`) `a`
                          GROUP BY `a`.`playerID`) `A` LEFT JOIN (SELECT
                                                                    count(0)                                                  AS `num`,
                                                                    `datasource`.`playerhistorymatchsummary`.`playerID`       AS `playerID`,
                                                                    `datasource`.`playerhistorymatchsummary`.`playerHeroName` AS `playerHeroName`
                                                                  FROM `datasource`.`playerhistorymatchsummary`
                                                                  GROUP BY
                                                                    `datasource`.`playerhistorymatchsummary`.`playerID`,
                                                                    `datasource`.`playerhistorymatchsummary`.`playerHeroName`) `B`
                       ON (((`a`.`playerID` = `b`.`playerID`) AND
                            (`a`.`maxNum` = `b`.`num`))))) `playerMaxHeroNameTable`
              JOIN (SELECT
                      `a`.`playerID`   AS `playerID`,
                      `a`.`maxNum`     AS `maxNum`,
                      `b`.`playerSlot` AS `playerMaxSlot`
                    FROM ((SELECT
                             max(`a`.`num`) AS `maxNum`,
                             `a`.`playerID` AS `playerID`
                           FROM (SELECT
                                   count(0)                                                         AS `num`,
                                   `datasource`.`playerhistorymatchsummary`.`playerID`              AS `playerID`,
                                   (CASE WHEN (`datasource`.`playerhistorymatchsummary`.`playerSlot` > 127)
                                     THEN (`datasource`.`playerhistorymatchsummary`.`playerSlot` - 128)
                                    ELSE `datasource`.`playerhistorymatchsummary`.`playerSlot` END) AS `playerSlot`
                                 FROM `datasource`.`playerhistorymatchsummary`
                                 GROUP BY `datasource`.`playerhistorymatchsummary`.`playerID`,
                                   `datasource`.`playerhistorymatchsummary`.`playerSlot`) `a`
                           GROUP BY `a`.`playerID`) `A` LEFT JOIN (SELECT
                                                                     count(0)                                                         AS `num`,
                                                                     `datasource`.`playerhistorymatchsummary`.`playerID`              AS `playerID`,
                                                                     (CASE WHEN (
                                                                       `datasource`.`playerhistorymatchsummary`.`playerSlot`
                                                                       > 127)
                                                                       THEN (
                                                                         `datasource`.`playerhistorymatchsummary`.`playerSlot`
                                                                         - 128)
                                                                      ELSE `datasource`.`playerhistorymatchsummary`.`playerSlot` END) AS `playerSlot`
                                                                   FROM `datasource`.`playerhistorymatchsummary`
                                                                   GROUP BY
                                                                     `datasource`.`playerhistorymatchsummary`.`playerID`,
                                                                     `datasource`.`playerhistorymatchsummary`.`playerSlot`) `B`
                        ON (((`a`.`playerID` = `b`.`playerID`) AND (`a`.`maxNum` = `b`.`num`))))) `playerMaxSlotTable`
                ON ((`playermaxheronametable`.`playerID` = `playermaxslottable`.`playerID`)))) `playerHistoryTableOne`
       JOIN (SELECT
               count(0)                                                                          AS `matchNum`,
               `datasource`.`playerhistorymatchsummary`.`playerID`                               AS `playerID`,
               sum(if((`datasource`.`playerhistorymatchsummary`.`playerLeaveStatus` > 0), 1, 0)) AS `totalLeaveNum`,
               (sum(`datasource`.`playerhistorymatchsummary`.`playerWin`) / count(0))            AS `playerWinRate`,
               (sum(`datasource`.`playerhistorymatchsummary`.`playerKills`) / count(0))          AS `playersAvgKills`,
               (sum(`datasource`.`playerhistorymatchsummary`.`playerAssists`) / count(0))        AS `playerAvgAssists`,
               (sum(`datasource`.`playerhistorymatchsummary`.`playerDeaths`) / count(0))         AS `playerAvgDeaths`,
               (sum(`datasource`.`playerhistorymatchsummary`.`playerDenies`) / count(0))         AS `playerAvgDenies`,
               (sum(`datasource`.`playerhistorymatchsummary`.`playerLastHits`) / count(0))       AS `playerAvgLastHits`,
               (sum(`datasource`.`playerhistorymatchsummary`.`playerGlod`) / count(0))           AS `playerAvgGlod`,
               (sum(`datasource`.`playerhistorymatchsummary`.`playerGlodSpent`) / count(
                   0))                                                                           AS `playerAvgGlodSpent`,
               (sum(`datasource`.`playerhistorymatchsummary`.`playerGPM`) / count(0))            AS `playerAvgGPM`,
               (sum(`datasource`.`playerhistorymatchsummary`.`playerXPM`) / count(0))            AS `playerAvgXPM`,
               (sum(`datasource`.`playerhistorymatchsummary`.`playerHeroDamage`) / count(
                   0))                                                                           AS `playerAvgHeroDamage`,
               (sum(`datasource`.`playerhistorymatchsummary`.`playerTowerDamage`) / count(
                   0))                                                                           AS `playerAvgTowerDamage`,
               (sum(`datasource`.`playerhistorymatchsummary`.`playerHeroHealing`) / count(
                   0))                                                                           AS `playerAvgHeroHealing`
             FROM `datasource`.`playerhistorymatchsummary`
             GROUP BY `datasource`.`playerhistorymatchsummary`.`playerID`) `playerHistoryTableTwo`
         ON ((`playerhistorytableone`.`playerID` = `playerhistorytabletwo`.`playerID`)))) `matchSummaryTwo`
      ON ((`matchsummaryone`.`playerID` = `matchsummarytwo`.`playerID`)));
